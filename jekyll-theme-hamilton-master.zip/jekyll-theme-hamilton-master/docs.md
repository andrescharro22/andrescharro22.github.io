---
layout: page
title: Docs
permalink: /docs/
---

A documentation page.
